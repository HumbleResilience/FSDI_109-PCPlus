import"./footer.css";

const Footer = () => {
   return(
       <div className="footer">
           <h4>PcPlus Store 2021. All rights reserved</h4>
           <h5>Eric Moore</h5>
       </div>
   ); 
}

export default Footer;